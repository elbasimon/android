package com.example.tictactoe;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;

import android.widget.TextView;

import android.view.View;

import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button[][] buttons = new Button[3][3];

    private boolean player1Turn = true;

    private int player1points;
    private int player2points;
    private int roundCount;

    private TextView textViewPlayer1; //display points of player1
    private TextView textViewPlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewPlayer1 = findViewById(R.id.text_view_p1);
        textViewPlayer2 = findViewById(R.id.text_view_p2);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);

            }
        }

        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }
        if (player1Turn) {
            ((Button) v).setText("X");
        } else {
            ((Button) v).setText("O");
        }

        roundCount++;

        if (checkForWin()) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 9) { //if draw
            draw();
        } else {
            player1Turn = !player1Turn; //no win and no draw case it will switch turns player1Turn(true)= !player1Turn(false)
        }

    }

    private boolean checkForWin() {
        String[][] field = new String[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString(); //go through all buttons and save in field[i][j].
            }
        }

        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1]) //for checking columns
                    && field[i][0].equals(field[i][2]) //checking for same x  as in xox.
                    && !field[i][0].equals("")) { //checking it's not empty field
                return true;
            }
        }

        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i]) //for checking rows.
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }

        if (field[0][0].equals(field[1][1]) //for diagonal checking from top left.
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }

        if (field[0][2].equals(field[1][1]) ////for diagonal checking from top right.
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }

        return false;
    }

    private void player1Wins() {
        player1points++;
        Toast.makeText(this, "Player 1 wins!", Toast.LENGTH_SHORT).show(); //to display message
        updatePointsText();
        resetBoard(); //to reset the game automatically.
    }

    private void player2Wins() {
        player2points++;
        Toast.makeText(this, "Player 2 wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void updatePointsText() {
        textViewPlayer1.setText("Player 1: " + player1points); //to set the points of player 1
        textViewPlayer2.setText("Player 2: " + player2points);
    }

    private void resetBoard() {
        for (int i = 0; i < 3; i++) { //loops through all rows and columns and reset to null.
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }

        roundCount = 0;
        player1Turn = true;
    }

    private void resetGame() { //reset button funcion (when we click on it)
        player2points = 0;
        player1points = 0;
        updatePointsText();
        resetBoard();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) { //to keep the values same when the orientation changes from
                                                          //portrait to landscape.
        super.onSaveInstanceState(outState);

        outState.putInt("roundCount", roundCount); //the roundcount will be saved under the key "roundCount" so it won't be changed
        outState.putInt("player1Points", player1points); //similarly player1points
        outState.putInt("player2Points", player2points);
        outState.putBoolean("player1Turn", player1Turn);

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) { //to read the values saved in outstate bundle to the app
        super.onRestoreInstanceState(savedInstanceState);

            roundCount = savedInstanceState.getInt("roundCount");
            player1points = savedInstanceState.getInt("player1Points");
            player2points = savedInstanceState.getInt("player2Points");
            player1Turn = savedInstanceState.getBoolean("player1Turn");
    }
}
